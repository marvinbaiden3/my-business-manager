
import json
import os
from datetime import datetime
from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup

DATA_FILE = "business_data.json"

DEFAULT = {
    "products": [],
    "sales": [],
    "expenses": [],
    "customers": [],
    "payments": []
}


class BusinessManager(App):
    def build(self):
        self.title = "My Business Manager"
        self.data = self.load_data()

        root = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(6))
        self.dashboard = Label(size_hint_y=None, height=dp(135), halign="left", valign="middle")
        root.add_widget(self.dashboard)

        buttons = [
            ("📦 INVENTORY", self.inventory),
            ("🛒 RECORD SALE", self.sale),
            ("💸 EXPENSE", self.expense),
            ("👤 CUSTOMERS", self.customers),
            ("💳 DEBT / PAYMENT", self.debts),
            ("📊 REPORTS", self.reports),
        ]
        grid = GridLayout(cols=2, spacing=dp(6))
        for text, callback in buttons:
            b = Button(text=text, font_size=dp(16))
            b.bind(on_press=callback)
            grid.add_widget(b)
        root.add_widget(grid)

        self.status = Label(text="Ready", size_hint_y=None, height=dp(30))
        root.add_widget(self.status)
        self.refresh()
        return root

    def load_data(self):
        if not os.path.exists(DATA_FILE):
            return {k: list(v) for k, v in DEFAULT.items()}
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                d = json.load(f)
            for k in DEFAULT:
                d.setdefault(k, [])
            return d
        except Exception:
            return {k: list(v) for k, v in DEFAULT.items()}

    def save(self):
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=2, ensure_ascii=False)

    def money(self, n):
        return f"GH₵{n:,.2f}"

    def totals(self):
        sales = self.data["sales"]
        revenue = sum(x["revenue"] for x in sales)
        cost = sum(x["cost"] for x in sales)
        profit = revenue - cost
        expenses = sum(x["amount"] for x in self.data["expenses"])
        net = profit - expenses
        debt = sum(x["balance"] for x in self.data["customers"])
        stock_value = sum(p["buy"] * p["stock"] for p in self.data["products"])
        return revenue, cost, profit, expenses, net, debt, stock_value

    def refresh(self):
        r, c, p, e, net, debt, stock = self.totals()
        self.dashboard.text = (
            "[b]BUSINESS DASHBOARD[/b]\n"
            f"Sales: {self.money(r)}    Cost: {self.money(c)}\n"
            f"Gross profit: {self.money(p)}\n"
            f"Expenses: {self.money(e)}\n"
            f"[b]NET PROFIT: {self.money(net)}[/b]\n"
            f"Customer debt: {self.money(debt)}    Stock value: {self.money(stock)}"
        )
        self.dashboard.markup = True

    def popup(self, title, content, size=(0.94, 0.86)):
        p = Popup(title=title, content=content, size_hint=size)
        p.open()
        return p

    def form(self, fields, save_text, callback):
        box = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(7))
        inputs = {}
        for key, hint, filt in fields:
            t = TextInput(hint_text=hint, multiline=False, input_filter=filt,
                          size_hint_y=None, height=dp(48))
            inputs[key] = t
            box.add_widget(t)
        save = Button(text=save_text, size_hint_y=None, height=dp(50))
        save.bind(on_press=lambda _: callback(inputs))
        box.add_widget(save)
        return box

    def inventory(self, _):
        box = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(7))
        add = Button(text="ADD PRODUCT", size_hint_y=None, height=dp(48))
        view = Button(text="VIEW INVENTORY", size_hint_y=None, height=dp(48))
        box.add_widget(add); box.add_widget(view)
        p = self.popup("INVENTORY", box, (0.94, 0.7))

        def add_product(_):
            fields = [
                ("name", "Product name", None),
                ("buy", "Buying price per item", "float"),
                ("sell", "Selling price per item", "float"),
                ("stock", "Quantity in stock", "int"),
            ]
            form = self.form(fields, "SAVE PRODUCT", lambda d: save_product(d))
            p.dismiss()
            self.popup("ADD PRODUCT", form, (0.94, 0.72))

        def save_product(d):
            try:
                name = d["name"].text.strip()
                buy = float(d["buy"].text); sell = float(d["sell"].text); stock = int(d["stock"].text)
                if not name or buy < 0 or sell < 0 or stock < 0: raise ValueError()
                self.data["products"].append({"name": name, "buy": buy, "sell": sell, "stock": stock})
                self.save(); self.refresh(); self.status.text = "Product saved."
            except Exception:
                self.message("Error", "Enter valid product information.")

        def view_inventory(_):
            rows = []
            for x in self.data["products"]:
                rows.append(f"{x['name']}\nBuy: {self.money(x['buy'])} | Sell: {self.money(x['sell'])} | Stock: {x['stock']}")
            self.message("INVENTORY", "\n\n".join(rows) if rows else "No products yet.")

        add.bind(on_press=add_product); view.bind(on_press=view_inventory)

    def sale(self, _):
        names = [p["name"] for p in self.data["products"]]
        fields = [
            ("name", "Product name (must match inventory)", None),
            ("qty", "Quantity sold", "int"),
            ("customer", "Customer name (optional)", None),
            ("paid", "Amount paid now (GH₵)", "float"),
        ]
        box = self.form(fields, "RECORD SALE", save_sale)
        self.popup("RECORD SALE", box, (0.94, 0.75))

        def save_sale(d):
            try:
                name = d["name"].text.strip()
                qty = int(d["qty"].text)
                customer = d["customer"].text.strip()
                paid = float(d["paid"].text or 0)
                product = next((x for x in self.data["products"] if x["name"].lower() == name.lower()), None)
                if not product or qty <= 0 or paid < 0 or qty > product["stock"]:
                    raise ValueError("Product not found, invalid quantity, or insufficient stock.")
                revenue = product["sell"] * qty
                cost = product["buy"] * qty
                balance = max(0, revenue - paid)
                product["stock"] -= qty
                self.data["sales"].append({
                    "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
                    "product": product["name"], "qty": qty,
                    "revenue": revenue, "cost": cost,
                    "paid": min(paid, revenue), "balance": balance,
                    "customer": customer
                })
                if customer and balance > 0:
                    existing = next((x for x in self.data["customers"] if x["name"].lower() == customer.lower()), None)
                    if existing:
                        existing["balance"] += balance
                    else:
                        self.data["customers"].append({"name": customer, "phone": "", "address": "", "balance": balance})
                self.save(); self.refresh()
                self.message("SALE SUCCESSFUL",
                             f"Revenue: {self.money(revenue)}\nCost: {self.money(cost)}\n"
                             f"Profit: {self.money(revenue-cost)}\nCustomer balance: {self.money(balance)}")
            except ValueError as e:
                self.message("Error", str(e) or "Enter valid sale information.")

    def expense(self, _):
        fields = [("name", "Expense name", None), ("amount", "Amount (GH₵)", "float")]
        self.popup("ADD EXPENSE", self.form(fields, "SAVE EXPENSE", save_expense), (0.94, 0.55))

        def save_expense(d):
            try:
                name = d["name"].text.strip(); amount = float(d["amount"].text)
                if not name or amount < 0: raise ValueError()
                self.data["expenses"].append({"date": datetime.now().strftime("%Y-%m-%d"), "name": name, "amount": amount})
                self.save(); self.refresh(); self.status.text = "Expense saved."
            except Exception:
                self.message("Error", "Enter a valid expense.")

    def customers(self, _):
        fields = [
            ("name", "Customer name", None),
            ("phone", "Phone number", None),
            ("address", "Address", None)
        ]
        self.popup("ADD CUSTOMER", self.form(fields, "SAVE CUSTOMER", save_customer), (0.94, 0.65))

        def save_customer(d):
            name = d["name"].text.strip()
            if not name or not d["phone"].text.strip():
                self.message("Error", "Name and phone are required."); return
            self.data["customers"].append({
                "name": name, "phone": d["phone"].text.strip(),
                "address": d["address"].text.strip(), "balance": 0
            })
            self.save(); self.status.text = "Customer saved."

    def debts(self, _):
        rows = []
        for c in self.data["customers"]:
            rows.append(f"{c['name']} — Debt: {self.money(c.get('balance',0))}\nPhone: {c.get('phone','')}")
        self.message("CUSTOMER DEBTS", "\n\n".join(rows) if rows else "No customers or debts.")

    def reports(self, _):
        r, c, p, e, net, debt, stock = self.totals()
        sales = self.data["sales"]
        today = datetime.now().strftime("%Y-%m-%d")
        today_sales = [x for x in sales if x["date"].startswith(today)]
        tr = sum(x["revenue"] for x in today_sales)
        tp = sum(x["revenue"]-x["cost"] for x in today_sales)
        text = (
            f"ALL-TIME\nSales: {self.money(r)}\nCost: {self.money(c)}\n"
            f"Gross profit: {self.money(p)}\nExpenses: {self.money(e)}\n"
            f"NET PROFIT: {self.money(net)}\n\n"
            f"TODAY ({today})\nSales: {self.money(tr)}\nProfit: {self.money(tp)}\n\n"
            f"Customers owing: {self.money(debt)}\nInventory value: {self.money(stock)}"
        )
        self.message("BUSINESS REPORT", text)

    def message(self, title, text):
        box = BoxLayout(orientation="vertical", padding=dp(10), spacing=dp(8))
        box.add_widget(Label(text=text, halign="left", valign="middle"))
        close = Button(text="CLOSE", size_hint_y=None, height=dp(48))
        p = Popup(title=title, content=box, size_hint=(0.92, 0.75))
        close.bind(on_press=p.dismiss)
        box.add_widget(close)
        p.open()


if __name__ == "__main__":
    BusinessManager().run()
