# My Business Manager

A Kivy Android business app for:
- Inventory and stock
- Recording sales
- Automatic revenue, cost and profit calculations
- Expenses and net profit
- Customers
- Customer debt tracking
- Daily and all-time reports
- Local data saved in JSON

## Fastest way to use it now
Install Pydroid 3 and Kivy on Android, then open `main.py` and run it.

## To make a real APK
Use Buildozer on Linux or a cloud Linux environment. The included GitHub Actions workflow can build an APK automatically.
